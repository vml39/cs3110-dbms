No installation needed.

Type `make query` in the command prompt **in the modules folder** to test a query. Current functionality only allows the user to SELECT from the database. Test tables are students and buildings.
Examples:
- SELECT * FROM students
- SELECT * FROM buildings 
- SELECT name FROM students
- SELECT netid, name FROM students